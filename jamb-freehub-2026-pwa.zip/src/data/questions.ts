export type Question = {
  id: string;
  subject: string;
  topic: string;
  question: string;
  options: { A: string; B: string; C: string; D: string };
  answer: 'A' | 'B' | 'C' | 'D';
  explanation: string;
};

// Generates an array of questions, repeating to simulate volume
export const getQuestions = (): Question[] => {
  const qList: Question[] = [];
  
  // English
  for (let i = 1; i <= 75; i++) {
    qList.push({
      id: `eng_${i}`,
      subject: 'English',
      topic: 'Lexis and Structure',
      question: `Choose the word nearest in meaning to the italicized word: The manager was *appalled* by the worker's attitude.`,
      options: { A: 'pleased', B: 'shocked', C: 'confused', D: 'indifferent' },
      answer: 'B',
      explanation: 'Appalled means filled with dismay or horror, which is synonymous with shocked.'
    }, {
      id: `eng_${i + 75}`,
      subject: 'English',
      topic: 'Comprehension',
      question: `Choose the option that best completes the sentence: Neither the students nor the teacher ______ present.`,
      options: { A: 'was', B: 'were', C: 'are', D: 'have been' },
      answer: 'A',
      explanation: 'According to the rule of proximity in concord, when "neither...nor" is used, the verb agrees with the noun closest to it. "Teacher" is singular, so "was" is correct.'
    }, {
      id: `eng_${i + 150}`,
      subject: 'English',
      topic: 'The Lekki Headmaster',
      question: `In The Lekki Headmaster, what is a primary theme explored by Kabir Alabi Garba?`,
      options: { A: 'Rural farming', B: 'Urban migration', C: 'Educational administration and integrity', D: 'Pre-colonial trade' },
      answer: 'C',
      explanation: 'The novel focuses heavily on the challenges of running a school in modern times, touching on integrity and administration.'
    });
  }

  // Literature
  for (let i = 1; i <= 75; i++) {
    qList.push({
      id: `lit_${i}`,
      subject: 'Literature',
      topic: 'Literary Devices',
      question: `Which literary device is used when a character speaks their thoughts aloud while alone on stage?`,
      options: { A: 'Dialogue', B: 'Monologue', C: 'Soliloquy', D: 'Aside' },
      answer: 'C',
      explanation: 'A soliloquy is a device often used in drama to reveal the innermost thoughts of a character, spoken aloud when alone.'
    }, {
      id: `lit_${i + 75}`,
      subject: 'Literature',
      topic: 'Drama (Shakespeare)',
      question: `In Antony & Cleopatra, what primary conflict drives the plot?`,
      options: { A: 'Duty vs. Passion', B: 'Man vs. Nature', C: 'Wealth vs. Poverty', D: 'Youth vs. Age' },
      answer: 'A',
      explanation: 'The struggle between Antony\'s political duties in Rome and his passionate love for Cleopatra in Egypt is the central conflict.'
    }, {
      id: `lit_${i + 150}`,
      subject: 'Literature',
      topic: 'African Poetry',
      question: `In Gabriel Okara's "Once Upon a Time," what does the poet lament?`,
      options: { A: 'The loss of innocence and genuine emotion', B: 'The destruction of the environment', C: 'The harshness of winter', D: 'The difficulty of farming' },
      answer: 'A',
      explanation: 'The poem discusses how societal changes have made people hypocritical, replacing genuine smiles with fake, "ice-block-cold" expressions.'
    });
  }

  // Government
  for (let i = 1; i <= 75; i++) {
    qList.push({
      id: `gov_${i}`,
      subject: 'Government',
      topic: 'Basic Concepts',
      question: `A system of government where power is concentrated in the hands of a few elites is called:`,
      options: { A: 'Democracy', B: 'Oligarchy', C: 'Autocracy', D: 'Monarchy' },
      answer: 'B',
      explanation: 'Oligarchy is defined as rule by a few, especially those who are wealthy or powerful.'
    }, {
      id: `gov_${i + 75}`,
      subject: 'Government',
      topic: 'Political Parties',
      question: `Which of the following was a major political party in Nigeria's First Republic?`,
      options: { A: 'PDP', B: 'APC', C: 'NPC', D: 'SDP' },
      answer: 'C',
      explanation: 'The Northern People\'s Congress (NPC) was one of the dominant parties in the First Republic of Nigeria (1960-1966).'
    });
  }

  // CRS
  for (let i = 1; i <= 75; i++) {
    qList.push({
      id: `crs_${i}`,
      subject: 'CRS',
      topic: 'Early Life of Jesus',
      question: `According to Luke's Gospel, where did Jesus\' parents find him after searching for three days?`,
      options: { A: 'In a manger', B: 'At the Jordan River', C: 'In the temple', D: 'On a mountain' },
      answer: 'C',
      explanation: 'They found him in the temple, sitting among the teachers, listening to them and asking them questions (Luke 2:46).'
    }, {
      id: `crs_${i + 75}`,
      subject: 'CRS',
      topic: 'The Early Church',
      question: `Who was chosen to replace Judas Iscariot as the twelfth apostle?`,
      options: { A: 'Paul', B: 'Matthias', C: 'Barnabas', D: 'Stephen' },
      answer: 'B',
      explanation: 'Matthias was chosen by casting lots to replace Judas Iscariot (Acts 1:26).'
    });
  }

  return qList;
};

export const questionsDB = getQuestions();
