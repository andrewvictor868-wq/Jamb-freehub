export const syllabusData = [
  {
    subject: 'Literature',
    description: 'Literature-in-English 2026 JAMB Syllabus',
    topics: [
      {
        title: 'Types of Drama',
        content: `
          <h3>Tragedy</h3> A play dealing with tragic events and having an unhappy ending, especially one concerning the downfall of the main character.
          <h3>Comedy</h3> A play characterized by its humorous or satirical tone and its depiction of amusing people or incidents, in which the characters ultimately triumph over adversity.
          <h3>Tragicomedy</h3> A play or novel containing elements of both comedy and tragedy.
          <h3>Melodrama</h3> A sensational dramatic piece with exaggerated characters and exciting events intended to appeal to the emotions.
          <h3>Farce</h3> A comic dramatic work using buffoonery and horseplay and typically including crude characterization and ludicrously improbable situations.
          <h3>Opera</h3> A dramatic work in one or more acts, set to music for singers and instrumentalists.
        `,
      },
      {
        title: 'Dramatic Techniques',
        content: `
          <h3>Characterization</h3> The creation or construction of a fictional character.
          <h3>Dialogue</h3> Conversation between two or more people as a feature of a book, play, or movie.
          <h3>Flashback</h3> A scene in a movie, novel, etc., set in a time earlier than the main story.
          <h3>Soliloquy</h3> An act of speaking one's thoughts aloud when by oneself or regardless of any hearers, especially by a character in a play.
          <h3>Aside</h3> A remark or passage by a character in a play that is intended to be heard by the audience but unheard by the other characters in the play.
        `,
      },
      {
        title: 'Recommended Texts (Drama)',
        content: `
          <h3>Antony & Cleopatra by William Shakespeare</h3> 
          <ul>
            <li><b>Themes:</b> Duty vs. Passion, East vs. West, Honor, Betrayal.</li>
            <li><b>Characters:</b> Mark Antony, Cleopatra, Octavius Caesar, Lepidus, Enobarbus.</li>
            <li><b>Plot:</b> The struggle of Antony to balance his duty as a triumvir of Rome and his obsessive love for the Queen of Egypt, Cleopatra, eventually leading to their tragic suicides.</li>
          </ul>
          <h3>The Marriage of Anansewa by Efua Sutherland</h3>
          <ul>
            <li><b>Themes:</b> Greed, Marriage, Materialism, Tradition.</li>
            <li><b>Characters:</b> Ananse, Anansewa, Christie.</li>
            <li><b>Plot:</b> Ananse tries to marry off his daughter Anansewa to multiple wealthy suitors simultaneously to solve his financial problems.</li>
          </ul>
          <h3>An Inspector Calls by J.B. Priestley</h3>
          <ul>
            <li><b>Themes:</b> Social Responsibility, Class, Age, Guilt.</li>
            <li><b>Characters:</b> Arthur Birling, Sybil Birling, Sheila Birling, Eric Birling, Gerald Croft, Inspector Goole, Eva Smith.</li>
            <li><b>Plot:</b> A mysterious Inspector interrogates a wealthy family about their role in the suicide of a young working-class woman.</li>
          </ul>
        `
      }
    ]
  },
  {
    subject: 'English',
    description: 'Use of English 2026 JAMB Syllabus',
    topics: [
      {
        title: 'Comprehension/Summary',
        content: `Ability to understand, summarize, and deduce meaning from passages.`
      },
      {
        title: 'Lexis and Structure',
        content: `Synonyms, antonyms, idioms, clausal structures, tense, and concord.`
      },
      {
        title: 'Compulsory Novel: The Lekki Headmaster',
        content: `
          <h3>The Lekki Headmaster by Kabir Alabi Garba</h3>
          <ul>
            <li><b>Summary:</b> A tale about educational administration, integrity, and challenges faced by a dedicated school head in contemporary Nigeria.</li>
            <li><b>Themes:</b> Corruption vs. Integrity, Modern Education, Societal Values.</li>
          </ul>
        `
      }
    ]
  },
  {
    subject: 'Government',
    description: 'Government 2026 JAMB Syllabus',
    topics: [
      {
        title: 'Basic Concepts in Government',
        content: `Power, Authority, Legitimacy, Sovereignty, Democracy, Political Culture, and Socialization.`
      },
      {
        title: 'Political Development in Nigeria',
        content: `Pre-colonial administration, colonial rule, nationalism, independence, and the various Republics.`
      }
    ]
  },
  {
    subject: 'CRS',
    description: 'Christian Religious Studies 2026 JAMB Syllabus',
    topics: [
      {
        title: 'Themes from the Old Testament',
        content: `Creation, The Patriarchs (Abraham, Isaac, Jacob), Joseph, Moses, Joshua, and the Judges.`
      },
      {
        title: 'Themes from the New Testament',
        content: `The birth, ministry, death, and resurrection of Jesus Christ. The early church in Acts of the Apostles.`
      }
    ]
  }
];
