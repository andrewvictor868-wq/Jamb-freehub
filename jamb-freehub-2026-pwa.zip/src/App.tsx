import { HashRouter, Routes, Route, Link } from 'react-router-dom';
import { BookOpen, PenTool, Monitor, Moon, Sun } from 'lucide-react';
import { useStore } from './store';
import HomePage from './pages/HomePage';
import ReadingMode from './pages/ReadingMode';
import PracticeMode from './pages/PracticeMode';
import CBTMode from './pages/CBTMode';
import CBTExam from './pages/CBTExam';

export default function App() {
  const { darkMode, toggleDarkMode } = useStore();

  return (
    <div className={darkMode ? 'dark' : ''}>
      <HashRouter>
        <div className="min-h-screen bg-gray-50 text-gray-900 dark:bg-gray-900 dark:text-gray-100 font-sans transition-colors duration-200 flex flex-col">
          {/* Navbar */}
          <nav className="bg-blue-700 text-white shadow-md sticky top-0 z-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex justify-between h-16">
                <div className="flex items-center">
                  <Link to="/" className="flex-shrink-0 flex items-center gap-2">
                    <Monitor className="w-8 h-8" />
                    <span className="font-bold text-xl hidden sm:block">JAMB FreeHub 2026</span>
                    <span className="font-bold text-xl sm:hidden">FreeHub</span>
                  </Link>
                </div>
                <div className="flex items-center space-x-4">
                  <Link to="/read" className="p-2 rounded-md hover:bg-blue-600 transition" title="Reading Mode"><BookOpen className="w-5 h-5" /></Link>
                  <Link to="/practice" className="p-2 rounded-md hover:bg-blue-600 transition" title="Practice Mode"><PenTool className="w-5 h-5" /></Link>
                  <Link to="/cbt" className="p-2 rounded-md hover:bg-blue-600 transition" title="CBT Mode"><Monitor className="w-5 h-5" /></Link>
                  <button onClick={toggleDarkMode} className="p-2 rounded-md hover:bg-blue-600 transition" title="Toggle Theme">
                    {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            </div>
          </nav>

          {/* Main Content */}
          <main className="flex-grow w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/read" element={<ReadingMode />} />
              <Route path="/practice" element={<PracticeMode />} />
              <Route path="/cbt" element={<CBTMode />} />
              <Route path="/cbt/exam" element={<CBTExam />} />
            </Routes>
          </main>

          {/* Footer */}
          <footer className="bg-white dark:bg-gray-800 shadow-inner mt-auto border-t dark:border-gray-700">
            <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex justify-between items-center text-sm text-gray-500 dark:text-gray-400">
              <p>&copy; 2026 JAMB FreeHub. 100% Free & Offline.</p>
              <p>English, Literature, Gov & CRS</p>
            </div>
          </footer>
        </div>
      </HashRouter>
    </div>
  );
}
