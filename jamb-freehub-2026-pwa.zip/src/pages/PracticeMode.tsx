import { useState } from 'react';
import { questionsDB } from '../data/questions';
import { PenTool, CheckCircle, XCircle } from 'lucide-react';
import { syllabusData } from '../data/syllabus';

export default function PracticeMode() {
  const [activeSubject, setActiveSubject] = useState(syllabusData[0].subject);
  const [selectedTopic, setSelectedTopic] = useState('All');
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  const filteredQuestions = questionsDB.filter(
    (q) => q.subject === activeSubject && (selectedTopic === 'All' || q.topic === selectedTopic)
  );

  const topics = ['All', ...Array.from(new Set(questionsDB.filter((q) => q.subject === activeSubject).map((q) => q.topic)))];

  const currentQ = filteredQuestions[currentQIndex];

  const handleSelectOption = (key: string) => {
    if (showExplanation) return;
    setSelectedOption(key);
    setShowExplanation(true);
  };

  const handleNext = () => {
    setCurrentQIndex((prev) => Math.min(prev + 1, filteredQuestions.length - 1));
    setSelectedOption(null);
    setShowExplanation(false);
  };

  const handlePrev = () => {
    setCurrentQIndex((prev) => Math.max(prev - 1, 0));
    setSelectedOption(null);
    setShowExplanation(false);
  };

  return (
    <div className="flex flex-col md:flex-row gap-6 h-[calc(100vh-8rem)]">
      {/* Sidebar Filters */}
      <aside className="w-full md:w-64 bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-4 border border-gray-100 dark:border-gray-700 h-full overflow-y-auto">
        <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
          <PenTool className="w-5 h-5" /> Subjects
        </h2>
        <nav className="space-y-2 mb-6">
          {syllabusData.map((s) => (
            <button
              key={s.subject}
              onClick={() => {
                setActiveSubject(s.subject);
                setSelectedTopic('All');
                setCurrentQIndex(0);
                setShowExplanation(false);
                setSelectedOption(null);
              }}
              className={`w-full text-left px-4 py-2 rounded-xl transition font-medium ${
                activeSubject === s.subject ? 'bg-blue-600 text-white shadow-md' : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              {s.subject}
            </button>
          ))}
        </nav>

        <h3 className="text-md font-semibold mb-3">Topics</h3>
        <select
          value={selectedTopic}
          onChange={(e) => {
            setSelectedTopic(e.target.value);
            setCurrentQIndex(0);
            setShowExplanation(false);
            setSelectedOption(null);
          }}
          className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-sm focus:ring-2 focus:ring-blue-500"
        >
          {topics.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </aside>

      {/* Main Content */}
      <div className="flex-1 bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 flex flex-col border border-gray-100 dark:border-gray-700">
        <div className="flex justify-between items-center mb-6 pb-4 border-b dark:border-gray-700">
          <h2 className="text-2xl font-bold">{activeSubject} Practice</h2>
          <span className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100 py-1 px-3 rounded-full text-sm font-semibold">
            Question {currentQIndex + 1} of {filteredQuestions.length}
          </span>
        </div>

        {currentQ ? (
          <div className="flex-1 overflow-y-auto">
            <h3 className="text-lg font-medium mb-2 text-gray-500 dark:text-gray-400 text-sm">Topic: {currentQ.topic}</h3>
            <p className="text-xl mb-8 leading-relaxed font-medium" dangerouslySetInnerHTML={{ __html: currentQ.question }} />

            <div className="space-y-4">
              {(Object.entries(currentQ.options) as [string, string][]).map(([key, text]) => {
                const isCorrect = key === currentQ.answer;
                const isSelected = selectedOption === key;

                let btnClass = "w-full text-left p-4 rounded-xl border-2 transition text-lg flex items-center justify-between ";
                if (!showExplanation) {
                  btnClass += "border-gray-200 dark:border-gray-700 hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-gray-700 bg-white dark:bg-gray-800";
                } else if (isCorrect) {
                  btnClass += "border-green-500 bg-green-50 dark:bg-green-900/30 text-green-900 dark:text-green-100";
                } else if (isSelected) {
                  btnClass += "border-red-500 bg-red-50 dark:bg-red-900/30 text-red-900 dark:text-red-100";
                } else {
                  btnClass += "border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 opacity-50";
                }

                return (
                  <button
                    key={key}
                    onClick={() => handleSelectOption(key)}
                    disabled={showExplanation}
                    className={btnClass}
                  >
                    <span className="flex items-center gap-3">
                      <span className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center font-bold">{key}</span>
                      <span dangerouslySetInnerHTML={{ __html: text }} />
                    </span>
                    {showExplanation && isCorrect && <CheckCircle className="w-6 h-6 text-green-500" />}
                    {showExplanation && isSelected && !isCorrect && <XCircle className="w-6 h-6 text-red-500" />}
                  </button>
                );
              })}
            </div>

            {showExplanation && (
              <div className="mt-8 p-6 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-xl animate-fade-in">
                <h4 className="font-bold mb-2 flex items-center gap-2 text-blue-800 dark:text-blue-300">
                  Explanation
                </h4>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed" dangerouslySetInnerHTML={{ __html: currentQ.explanation }} />
              </div>
            )}
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <p className="text-gray-500 text-lg">No questions available for this topic.</p>
          </div>
        )}

        {/* Navigation */}
        <div className="mt-6 pt-6 border-t dark:border-gray-700 flex justify-between items-center">
          <button
            onClick={handlePrev}
            disabled={currentQIndex === 0}
            className="px-6 py-3 bg-gray-200 dark:bg-gray-700 rounded-lg font-bold disabled:opacity-50 hover:bg-gray-300 dark:hover:bg-gray-600 transition"
          >
            Previous
          </button>
          <button
            onClick={handleNext}
            disabled={currentQIndex === filteredQuestions.length - 1}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg font-bold disabled:opacity-50 hover:bg-blue-700 transition"
          >
            Next Question
          </button>
        </div>
      </div>
    </div>
  );
}
