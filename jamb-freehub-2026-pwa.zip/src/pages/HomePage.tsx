import { Link } from 'react-router-dom';
import { BookOpen, PenTool, Monitor, Award, CheckCircle } from 'lucide-react';
import { useStore } from '../store';

export default function HomePage() {
  const { progress } = useStore();

  const subjects = ['English', 'Literature', 'Government', 'CRS'];

  return (
    <div className="space-y-12">
      <section className="text-center py-16 bg-gradient-to-r from-blue-700 to-indigo-800 text-white rounded-3xl shadow-2xl overflow-hidden relative">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="relative z-10 px-6">
          <h1 className="text-5xl font-extrabold mb-4 tracking-tight">Smash Your 2026 JAMB UTME</h1>
          <p className="text-xl max-w-2xl mx-auto mb-8 font-light">The ultimate 100% free offline-first PWA for English, Literature, Government & CRS. No ads. No fees. Just focus.</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/read" className="bg-white text-blue-800 px-8 py-4 rounded-full font-bold shadow-lg hover:bg-gray-100 transition flex items-center gap-2">
              <BookOpen className="w-5 h-5" /> Start Reading
            </Link>
            <Link to="/cbt" className="bg-blue-600 border-2 border-white text-white px-8 py-4 rounded-full font-bold shadow-lg hover:bg-blue-500 transition flex items-center gap-2">
              <Monitor className="w-5 h-5" /> Take CBT Mock
            </Link>
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-3xl font-bold mb-8 text-center text-gray-800 dark:text-gray-100 flex items-center justify-center gap-2">
          <Award className="text-yellow-500" /> Your Progress
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {subjects.map((sub) => {
            const score = progress[sub] || 0;
            return (
              <div key={sub} className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700 hover:shadow-xl transition transform hover:-translate-y-1">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold">{sub}</h3>
                  <CheckCircle className={`w-6 h-6 ${score > 0 ? 'text-green-500' : 'text-gray-300 dark:text-gray-600'}`} />
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
                  <div
                    className="bg-blue-600 h-3 rounded-full transition-all duration-1000 ease-out"
                    style={{ width: `${Math.min((score / 500) * 100, 100)}%` }}
                  ></div>
                </div>
                <p className="mt-3 text-sm text-gray-500 dark:text-gray-400 font-medium">{score} XP Points</p>
              </div>
            );
          })}
        </div>
      </section>

      <section className="bg-gray-100 dark:bg-gray-800 rounded-3xl p-8 shadow-inner">
        <h2 className="text-2xl font-bold mb-6 text-center">Core Features</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center space-y-3 p-4">
            <div className="bg-blue-100 dark:bg-blue-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto text-blue-600 dark:text-blue-300">
              <BookOpen className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-lg">Full 2026 Syllabus</h3>
            <p className="text-gray-600 dark:text-gray-400 text-sm">Every literary device, every prescribed text covered perfectly.</p>
          </div>
          <div className="text-center space-y-3 p-4">
            <div className="bg-green-100 dark:bg-green-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto text-green-600 dark:text-green-300">
              <PenTool className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-lg">Practice Mode</h3>
            <p className="text-gray-600 dark:text-gray-400 text-sm">Untimed topic-wise questions with detailed explanations.</p>
          </div>
          <div className="text-center space-y-3 p-4">
            <div className="bg-purple-100 dark:bg-purple-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto text-purple-600 dark:text-purple-300">
              <Monitor className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-lg">Realistic CBT</h3>
            <p className="text-gray-600 dark:text-gray-400 text-sm">Exact clone of the JAMB interface to build your exam speed.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
