import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { questionsDB, Question } from '../data/questions';
import { Calculator, ArrowLeft, ArrowRight, Save, Clock, HelpCircle } from 'lucide-react';
import { useStore } from '../store';

type ExamState = {
  [subject: string]: {
    questions: Question[];
    answers: Record<string, string>; // questionId -> optionKey
  };
};

export default function CBTExam() {
  const navigate = useNavigate();
  const { updateProgress } = useStore();
  const [examSettings, setExamSettings] = useState<{ subjects: string[]; numQuestions: number } | null>(null);
  const [examState, setExamState] = useState<ExamState>({});
  const [activeSubject, setActiveSubject] = useState<string>('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [showCalculator, setShowCalculator] = useState(false);
  const [calcInput, setCalcInput] = useState('');
  const [isFinished, setIsFinished] = useState(false);

  useEffect(() => {
    const settings = localStorage.getItem('cbtSettings');
    if (!settings) {
      navigate('/cbt');
      return;
    }
    const parsed = JSON.parse(settings);
    setExamSettings(parsed);

    // Initialize Exam State
    const initialState: ExamState = {};
    parsed.subjects.forEach((sub: string) => {
      const subQs = questionsDB.filter(q => q.subject === sub).sort(() => 0.5 - Math.random()).slice(0, parsed.numQuestions);
      initialState[sub] = { questions: subQs, answers: {} };
    });
    setExamState(initialState);
    setActiveSubject(parsed.subjects[0]);
    setTimeLeft(parsed.numQuestions * parsed.subjects.length * 72); // 1.2 mins per question
  }, [navigate]);

  useEffect(() => {
    if (timeLeft > 0 && !isFinished) {
      const timerId = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timerId);
    } else if (timeLeft === 0 && examSettings) {
      handleFinish();
    }
  }, [timeLeft, isFinished, examSettings]);

  const handleKeydown = useCallback((e: KeyboardEvent) => {
    if (isFinished) return;
    const key = e.key.toUpperCase();
    if (['A', 'B', 'C', 'D'].includes(key)) handleAnswer(key);
    if (key === 'N') handleNext();
    if (key === 'P') handlePrev();
  }, [isFinished, activeSubject, currentIndex, examState]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeydown);
    return () => window.removeEventListener('keydown', handleKeydown);
  }, [handleKeydown]);

  const handleAnswer = (optionKey: string) => {
    if (!activeSubject) return;
    const currentQId = examState[activeSubject].questions[currentIndex].id;
    setExamState(prev => ({
      ...prev,
      [activeSubject]: {
        ...prev[activeSubject],
        answers: { ...prev[activeSubject].answers, [currentQId]: optionKey }
      }
    }));
  };

  const handleNext = () => {
    if (!activeSubject) return;
    if (currentIndex < examState[activeSubject].questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      const subIdx = examSettings?.subjects.indexOf(activeSubject) || 0;
      if (examSettings && subIdx < examSettings.subjects.length - 1) {
        setActiveSubject(examSettings.subjects[subIdx + 1]);
        setCurrentIndex(0);
      }
    }
  };

  const handlePrev = () => {
    if (!activeSubject) return;
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    } else {
      const subIdx = examSettings?.subjects.indexOf(activeSubject) || 0;
      if (examSettings && subIdx > 0) {
        setActiveSubject(examSettings.subjects[subIdx - 1]);
        const prevSubQs = examState[examSettings.subjects[subIdx - 1]].questions.length;
        setCurrentIndex(prevSubQs - 1);
      }
    }
  };

  const handleFinish = () => {
    setIsFinished(true);
    // Calculate Score and update progress
    Object.keys(examState).forEach(sub => {
      let score = 0;
      examState[sub].questions.forEach(q => {
        if (examState[sub].answers[q.id] === q.answer) score += 10;
      });
      updateProgress(sub, score);
    });
  };

  const formatTime = (secs: number) => {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (!examSettings || !activeSubject) return <div className="text-center p-20">Loading CBT Engine...</div>;

  const currentSubjectData = examState[activeSubject];
  const currentQ = currentSubjectData.questions[currentIndex];
  const currentAnswer = currentSubjectData.answers[currentQ?.id];

  if (isFinished) {
    return (
      <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl max-w-4xl mx-auto border border-gray-100 dark:border-gray-700">
        <h1 className="text-4xl font-black text-center mb-8 text-green-600">Mock Result Breakdown</h1>
        {examSettings.subjects.map(sub => {
          const subData = examState[sub];
          const correct = subData.questions.filter(q => subData.answers[q.id] === q.answer).length;
          const total = subData.questions.length;
          return (
            <div key={sub} className="mb-6 p-6 border-2 border-gray-100 dark:border-gray-700 rounded-xl">
              <div className="flex justify-between items-center mb-4 border-b pb-2 dark:border-gray-700">
                <h2 className="text-2xl font-bold">{sub}</h2>
                <span className="text-2xl font-extrabold text-blue-600">{correct} / {total}</span>
              </div>
              <div className="space-y-4">
                {subData.questions.map((q, idx) => {
                  const uAns = subData.answers[q.id];
                  const isCorrect = uAns === q.answer;
                  return (
                    <div key={q.id} className={`p-4 rounded-lg border-l-4 ${isCorrect ? 'border-green-500 bg-green-50 dark:bg-green-900/20' : 'border-red-500 bg-red-50 dark:bg-red-900/20'}`}>
                      <p className="font-bold mb-2">Q{idx + 1}: <span dangerouslySetInnerHTML={{ __html: q.question }} /></p>
                      <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">Your Answer: <strong className={isCorrect ? 'text-green-700 dark:text-green-400' : 'text-red-700 dark:text-red-400'}>{uAns || 'None'}</strong> - Correct: <strong className="text-green-700 dark:text-green-400">{q.answer}</strong></p>
                      <p className="text-sm bg-white dark:bg-gray-800 p-3 rounded shadow-inner" dangerouslySetInnerHTML={{ __html: q.explanation }} />
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
        <button onClick={() => navigate('/cbt')} className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl shadow-lg hover:bg-blue-700 transition">Return to Dashboard</button>
      </div>
    );
  }

  return (
    <div className="h-[90vh] flex flex-col -m-6 rounded-none bg-gray-50 dark:bg-gray-900 overflow-hidden">
      {/* Top Header - JAMB Style */}
      <header className="bg-green-700 text-white p-3 flex justify-between items-center shadow-md shrink-0 border-b-4 border-yellow-500">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center font-black text-green-700 text-xs text-center border-2 border-green-900 shadow-inner leading-none uppercase">
            JAMB<br/>CBT
          </div>
          <div>
            <h1 className="font-extrabold text-lg tracking-wide uppercase shadow-sm text-shadow">2026 UTME Examination</h1>
            <p className="text-sm text-green-100 font-medium">Reg No: FREEHUB-2026-001</p>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="text-right">
            <div className="flex items-center gap-2 text-yellow-300 font-mono text-2xl font-black tracking-widest drop-shadow-md bg-green-900/40 px-3 py-1 rounded border border-green-800 shadow-inner">
              <Clock className="w-6 h-6" /> {formatTime(timeLeft)}
            </div>
          </div>
          <button onClick={() => setShowCalculator(!showCalculator)} className="bg-green-800 hover:bg-green-900 p-2 rounded-lg border border-green-600 shadow-md transition group relative">
             <Calculator className="w-6 h-6 text-green-100 group-hover:text-white" />
          </button>
          <button onClick={() => {if(window.confirm('Submit Final Exam?')) handleFinish()}} className="bg-red-600 hover:bg-red-700 text-white px-5 py-2 rounded-lg font-bold border-2 border-red-800 shadow-lg flex items-center gap-2">
            <Save className="w-5 h-5" /> SUBMIT
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Nav */}
        <aside className="w-64 bg-white dark:bg-gray-800 border-r dark:border-gray-700 flex flex-col shrink-0">
          <div className="p-3 bg-gray-100 dark:bg-gray-700 border-b border-gray-300 dark:border-gray-600 flex justify-between gap-1 overflow-x-auto">
            {examSettings.subjects.map(sub => (
              <button
                key={sub}
                onClick={() => { setActiveSubject(sub); setCurrentIndex(0); }}
                className={`px-3 py-2 text-sm font-bold rounded-t-lg transition whitespace-nowrap border-t border-x border-b-0 ${activeSubject === sub ? 'bg-white dark:bg-gray-800 text-blue-700 dark:text-blue-300 border-gray-300 dark:border-gray-600' : 'bg-gray-200 dark:bg-gray-600 text-gray-600 dark:text-gray-300 border-transparent'}`}
              >
                {sub}
              </button>
            ))}
          </div>
          <div className="p-4 grid grid-cols-4 gap-2 overflow-y-auto content-start flex-1">
            {currentSubjectData.questions.map((q, idx) => {
              const isAnswered = !!currentSubjectData.answers[q.id];
              const isActive = idx === currentIndex;
              return (
                <button
                  key={q.id}
                  onClick={() => setCurrentIndex(idx)}
                  className={`w-10 h-10 rounded font-bold shadow-sm flex items-center justify-center border transition-all ${
                    isActive ? 'ring-2 ring-blue-500 ring-offset-1 ' : ''
                  } ${
                    isAnswered ? 'bg-green-500 text-white border-green-600' : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 border-gray-300 dark:border-gray-600 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  {idx + 1}
                </button>
              );
            })}
          </div>
        </aside>

        {/* Question Area */}
        <main className="flex-1 bg-white dark:bg-gray-900 p-8 flex flex-col overflow-y-auto relative shadow-inner">
          
          {/* Calculator Overlay */}
          {showCalculator && (
             <div className="absolute top-4 right-4 bg-gray-900 text-white p-4 rounded-xl shadow-2xl z-50 border-2 border-gray-700 w-64 draggable">
               <div className="flex justify-between items-center mb-3">
                 <span className="font-bold text-sm text-gray-400">JAMB Calculator</span>
                 <button onClick={()=>setShowCalculator(false)} className="text-red-400 hover:text-red-300 font-bold px-2 py-1 rounded bg-gray-800 hover:bg-gray-700">X</button>
               </div>
               <input type="text" value={calcInput} readOnly className="w-full bg-gray-800 text-green-400 font-mono text-xl p-3 rounded mb-3 text-right border border-gray-700 shadow-inner" placeholder="0" />
               <div className="grid grid-cols-4 gap-2">
                 {['7','8','9','/','4','5','6','*','1','2','3','-','C','0','.','+','='].map(btn => (
                   <button key={btn}
                     onClick={() => {
                       if (btn === 'C') setCalcInput('');
                       else if (btn === '=') { try { setCalcInput(eval(calcInput).toString()) } catch { setCalcInput('Error') } }
                       else setCalcInput(prev => (prev === 'Error' ? btn : prev + btn))
                     }}
                     className={`p-3 font-bold text-lg rounded shadow-sm active:translate-y-px transition-colors ${
                       ['/','*','-','+','='].includes(btn) ? 'bg-orange-600 hover:bg-orange-500' : 
                       btn === 'C' ? 'bg-red-600 hover:bg-red-500' : 'bg-gray-700 hover:bg-gray-600'
                     } ${btn === '=' ? 'col-span-4' : ''}`}
                   >{btn}</button>
                 ))}
               </div>
             </div>
          )}

          <div className="flex-1 max-w-4xl mx-auto w-full">
            <div className="flex justify-between items-end border-b-2 border-gray-200 dark:border-gray-700 pb-3 mb-6">
              <h2 className="text-3xl font-black text-gray-800 dark:text-gray-100">Question {currentIndex + 1}</h2>
              <span className="text-gray-500 dark:text-gray-400 font-medium tracking-wide text-sm flex items-center gap-1">
                <HelpCircle className="w-4 h-4"/> {activeSubject}
              </span>
            </div>
            
            <div className="bg-blue-50/50 dark:bg-gray-800 p-6 rounded-xl border border-blue-100 dark:border-gray-700 mb-8 shadow-sm">
               <p className="text-2xl leading-relaxed text-gray-900 dark:text-gray-100 font-serif" dangerouslySetInnerHTML={{ __html: currentQ.question }} />
            </div>

            <div className="space-y-4">
              {(Object.entries(currentQ.options) as [string, string][]).map(([key, text]) => {
                const isSelected = currentAnswer === key;
                return (
                  <button
                    key={key}
                    onClick={() => handleAnswer(key)}
                    className={`w-full text-left p-5 rounded-xl border-2 transition-all flex items-center group shadow-sm ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/30'
                        : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:border-blue-300 hover:shadow-md'
                    }`}
                  >
                    <span className={`w-10 h-10 rounded-full flex items-center justify-center font-black text-lg shadow-inner mr-5 flex-shrink-0 transition-colors ${
                      isSelected ? 'bg-blue-600 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 group-hover:bg-blue-100 dark:group-hover:bg-gray-600'
                    }`}>
                      {key}
                    </span>
                    <span className="text-xl text-gray-800 dark:text-gray-200" dangerouslySetInnerHTML={{ __html: text }} />
                  </button>
                );
              })}
            </div>
          </div>
        </main>
      </div>

      {/* Bottom Bar Nav */}
      <footer className="bg-gray-100 dark:bg-gray-800 p-4 border-t border-gray-300 dark:border-gray-700 flex justify-between items-center shadow-inner shrink-0">
        <button
          onClick={handlePrev}
          disabled={activeSubject === examSettings.subjects[0] && currentIndex === 0}
          className="bg-gray-300 dark:bg-gray-700 text-gray-800 dark:text-gray-200 hover:bg-gray-400 dark:hover:bg-gray-600 px-6 py-3 rounded-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 transition"
        >
          <ArrowLeft className="w-5 h-5" /> Previous (P)
        </button>

        <div className="hidden md:flex gap-4 font-mono text-sm text-gray-500">
           <span>A, B, C, D - Select Option</span>
           <span>N - Next</span>
           <span>P - Previous</span>
        </div>

        <button
          onClick={handleNext}
          className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-bold shadow-lg flex items-center gap-2 transition transform active:scale-95"
        >
          {activeSubject === examSettings.subjects[examSettings.subjects.length - 1] && currentIndex === currentSubjectData.questions.length - 1 
            ? 'End of Questions' 
            : 'Next (N)'}
          <ArrowRight className="w-5 h-5" />
        </button>
      </footer>
    </div>
  );
}
