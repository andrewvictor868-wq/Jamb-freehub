import { useState } from 'react';
import { syllabusData } from '../data/syllabus';
import { BookOpen, ChevronRight, ChevronDown } from 'lucide-react';

export default function ReadingMode() {
  const [activeSubject, setActiveSubject] = useState(syllabusData[0].subject);
  const [expandedTopics, setExpandedTopics] = useState<string[]>([]);

  const toggleTopic = (title: string) => {
    setExpandedTopics((prev) =>
      prev.includes(title) ? prev.filter((t) => t !== title) : [...prev, title]
    );
  };

  const subjectData = syllabusData.find((s) => s.subject === activeSubject);

  return (
    <div className="flex flex-col md:flex-row gap-6">
      {/* Sidebar */}
      <aside className="w-full md:w-64 flex-shrink-0">
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-4 sticky top-20 border border-gray-100 dark:border-gray-700">
          <h2 className="text-lg font-bold mb-4 px-2 flex items-center gap-2">
            <BookOpen className="w-5 h-5" /> Subjects
          </h2>
          <nav className="space-y-2">
            {syllabusData.map((s) => (
              <button
                key={s.subject}
                onClick={() => setActiveSubject(s.subject)}
                className={`w-full text-left px-4 py-3 rounded-xl transition font-medium ${
                  activeSubject === s.subject
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300'
                }`}
              >
                {s.subject}
              </button>
            ))}
          </nav>
        </div>
      </aside>

      {/* Content */}
      <div className="flex-1 bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 md:p-10 border border-gray-100 dark:border-gray-700">
        {subjectData && (
          <div>
            <h1 className="text-3xl font-extrabold mb-2">{subjectData.subject}</h1>
            <p className="text-gray-500 dark:text-gray-400 mb-8 pb-4 border-b dark:border-gray-700 text-lg">
              {subjectData.description}
            </p>

            <div className="space-y-6">
              {subjectData.topics.map((topic, idx) => {
                const isExpanded = expandedTopics.includes(topic.title);
                return (
                  <div key={idx} className="border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition">
                    <button
                      onClick={() => toggleTopic(topic.title)}
                      className="w-full flex justify-between items-center p-5 bg-gray-50 dark:bg-gray-800/50 hover:bg-blue-50 dark:hover:bg-gray-700 transition"
                    >
                      <h3 className="font-bold text-lg text-left">{topic.title}</h3>
                      {isExpanded ? <ChevronDown className="w-5 h-5 text-gray-500" /> : <ChevronRight className="w-5 h-5 text-gray-500" />}
                    </button>
                    {isExpanded && (
                      <div
                        className="p-6 prose dark:prose-invert max-w-none border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800"
                        dangerouslySetInnerHTML={{ __html: topic.content }}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
