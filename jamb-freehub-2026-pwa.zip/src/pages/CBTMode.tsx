import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Monitor, CheckSquare, Settings } from 'lucide-react';

export default function CBTMode() {
  const navigate = useNavigate();
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(['English']);
  const [numQuestions, setNumQuestions] = useState(40);

  const subjects = ['English', 'Literature', 'Government', 'CRS'];

  const toggleSubject = (sub: string) => {
    if (selectedSubjects.includes(sub)) {
      if (selectedSubjects.length > 1) {
        setSelectedSubjects(selectedSubjects.filter((s) => s !== sub));
      }
    } else {
      setSelectedSubjects([...selectedSubjects, sub]);
    }
  };

  const handleStart = () => {
    // Store exam settings in localStorage or pass via state
    localStorage.setItem('cbtSettings', JSON.stringify({ subjects: selectedSubjects, numQuestions }));
    navigate('/cbt/exam');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <Monitor className="w-16 h-16 mx-auto text-blue-600" />
        <h1 className="text-4xl font-extrabold">CBT Mock Examination</h1>
        <p className="text-lg text-gray-600 dark:text-gray-400">Experience a realistic JAMB UTME testing environment.</p>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 border border-gray-100 dark:border-gray-700 space-y-8">
        <div>
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2 border-b pb-2 dark:border-gray-700">
            <Settings className="w-5 h-5" /> Select Subjects
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {subjects.map((sub) => {
              const isSelected = selectedSubjects.includes(sub);
              return (
                <button
                  key={sub}
                  onClick={() => toggleSubject(sub)}
                  className={`flex items-center gap-3 p-4 rounded-xl border-2 transition-all font-semibold text-lg ${
                    isSelected
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30 text-blue-800 dark:text-blue-100'
                      : 'border-gray-200 dark:border-gray-700 hover:border-blue-300 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  <CheckSquare className={`w-6 h-6 ${isSelected ? 'text-blue-600' : 'text-gray-300'}`} />
                  {sub}
                  {sub === 'English' && <span className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full ml-auto">Compulsory</span>}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2 border-b pb-2 dark:border-gray-700">
            Questions per Subject
          </h2>
          <div className="flex gap-4">
            {[10, 20, 40, 50].map((num) => (
              <button
                key={num}
                onClick={() => setNumQuestions(num)}
                className={`flex-1 py-3 rounded-lg font-bold border-2 transition-all ${
                  numQuestions === num
                    ? 'border-blue-600 bg-blue-600 text-white shadow-md'
                    : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 bg-white dark:bg-gray-800'
                }`}
              >
                {num}
              </button>
            ))}
          </div>
        </div>

        <div className="pt-6 border-t dark:border-gray-700 text-center">
          <p className="mb-4 text-gray-500 font-medium">
            Time Limit: <strong className="text-black dark:text-white">{(numQuestions * selectedSubjects.length * 1.2).toFixed(0)} minutes</strong>
          </p>
          <button
            onClick={handleStart}
            className="w-full bg-green-600 hover:bg-green-500 text-white font-extrabold text-2xl py-4 rounded-xl shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1 flex items-center justify-center gap-3"
          >
            <Monitor className="w-8 h-8" /> START EXAM NOW
          </button>
        </div>
      </div>
    </div>
  );
}
