import { create } from 'zustand';
import { persist } from 'zustand/middleware';

type StoreState = {
  darkMode: boolean;
  toggleDarkMode: () => void;
  bookmarks: string[];
  toggleBookmark: (id: string) => void;
  progress: Record<string, number>;
  updateProgress: (subject: string, score: number) => void;
};

export const useStore = create<StoreState>()(
  persist(
    (set) => ({
      darkMode: false,
      toggleDarkMode: () => set((state) => ({ darkMode: !state.darkMode })),
      bookmarks: [],
      toggleBookmark: (id) =>
        set((state) => ({
          bookmarks: state.bookmarks.includes(id)
            ? state.bookmarks.filter((b) => b !== id)
            : [...state.bookmarks, id],
        })),
      progress: {},
      updateProgress: (subject, score) =>
        set((state) => ({
          progress: {
            ...state.progress,
            [subject]: (state.progress[subject] || 0) + score,
          },
        })),
    }),
    {
      name: 'jamb-freehub-store',
    }
  )
);
